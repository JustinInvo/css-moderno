CSS.registerProperty({
    name: "--creada-con-javascript",
    syntax: "<color>",
    inherits: true,
    initialValue: "seagreen",
});